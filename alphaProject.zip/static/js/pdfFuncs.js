function clear_up() {
    window.print();
    window.document.body.innerHTML = ""
    window.document.head.innerHTML = ""
}